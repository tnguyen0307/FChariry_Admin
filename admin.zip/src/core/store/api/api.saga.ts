import { call, put, takeLatest } from 'redux-saga/effects';

import { apiActions } from '.';

function* getAllUserRole(): any {}

export default function* apiSaga() {}
