export interface TokenModel {
    token: string;
    refreshToken: string;
}
