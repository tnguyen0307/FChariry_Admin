declare module 'quill-blot-formatter/dist/BlotFormatter';
